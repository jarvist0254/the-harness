# Mechanical Blueprint — Universal 3-GPU Pod

## Printer hard constraint

Creality Ender-3 S1 Pro nominal build volume:
- X = 220mm
- Y = 220mm
- Z = 270mm

The core chassis shall be designed to fit within a **205 × 205 × 250mm design box** before slicer-added brim/skirt. Astra may reduce any dimension. Increasing beyond this box requires an explicit printer-fit check.

## Coordinate system

```text
X = left/right across the three GPU bays
Y = front fan/plenum toward rear GPU overhang
Z = vertical
```

GPU orientation:
- Full-height cards upright in normal motherboard orientation.
- GPU length runs along +Y.
- GPU height runs along +Z.
- Card thickness consumes X.
- GPU fan faces must not point down into the furniture shelf.

## Universal GPU acceptance envelope

The pod should natively accept three cards within this target envelope:

- card length: 180–360mm
- card height: 100–155mm
- card body thickness: 35–60mm nominal adjustable range
- card mass: up to 2.0kg per position
- full-height dual-slot I/O bracket compatible
- top/rear auxiliary-power protrusion allowance: 45mm minimum service space

The printed core does **not** need to surround the full card. Long cards may overhang the rear. Thick outer cards may partially overhang open side windows if their carrier remains mechanically supported.

Cards thicker than ~60mm, unusual four-slot coolers, or cards above 2kg are not automatically rejected, but three-at-once fit must be revalidated. The universal claim means broad 2–3-slot compatibility, not physically impossible packing of three arbitrary 4-slot GPUs inside a 220mm printer envelope.

## Adjustable carrier concept

Use three independent carrier stations A/B/C.

Each station consists of:
1. rigid receiver-board/electronics sled interface at the front/lower datum;
2. metal I/O bracket retention point;
3. adjustable mid/rear GPU body cradle touching only a verified safe shroud/backplate region;
4. cable strain-relief anchor independent of the PCIe edge/receiver connector.

### Carrier centerline range

Astra should model the three GPU carrier centerlines as parameters rather than fixed coordinates.

Suggested starting centers within the 205mm core:
- A: X = 32mm
- B: X = 102.5mm
- C: X = 173mm

Nominal center pitch = 70.5mm.

Carrier rails should permit approximately ±10mm local adjustment through metal-fastened slots. Outer carrier bodies may project through side windows. The design target is a **minimum clear cooling lane of 15mm wherever a GPU fan intake faces the next obstruction**, with 18–25mm preferred for hotter cards.

## Rear overhang strategy

The printed core depth is intentionally shorter than many GPUs.

- Core structural depth target: 190–205mm.
- GPU may extend 30–170mm beyond the rear depending on card length.
- Rear body cradle shall be located on a sliding or multi-position rail within the printed core, as far rearward as the chassis allows.
- If a long/heavy card's center of mass extends too far past the core, use a removable metal/printed outrigger that bolts into M4 inserts; do not simply thicken the whole chassis.

## Structural load paths

The monolithic print should behave like a ribbed space frame, not a solid box.

Primary load paths:
- bottom longitudinal beams under each carrier
- front I/O/bracket bulkhead
- two vertical side spines
- top cross tie
- PSU saddle/bay bridge (if PSU integrated physically)
- fan wall perimeter

All major corners receive generous internal radii and triangular gussets.

Recommended geometric starting values:
- low-load wall: 2.4mm
- primary vertical spine: 4.2–5.4mm effective section
- bottom beam web: 4.2–6.0mm effective section
- gusset thickness: 4.2–6.0mm
- local insert boss OD: per insert family, generally insert OD + 5–7mm radial material
- corner radii: ≥6mm where geometry permits

## Open structure / material removal

Do not print a solid floor.

Use:
- two or three longitudinal bottom beams
- transverse webs only at carrier stations / PSU anchors / fan wall
- large open windows in side panels
- lattice/rib bridges rather than full panels
- perforated cable raceway covers rather than solid covers

Target open area for cosmetic/guard panels: 55–70%.

## PSU relationship

The external PSU remains in its factory metal enclosure.

The pod may include a locating saddle and anti-slide strap interface. The print must not replace the PSU enclosure and must not rely on self-tapping screws into plastic.

The exact PSU dimensions remain a parameter until the final SKU is purchased. Current Corsair RM1000e-class reference dimensions are 140 × 150 × 86mm.

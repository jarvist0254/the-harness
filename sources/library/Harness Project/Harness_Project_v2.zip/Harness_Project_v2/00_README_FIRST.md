# JE Horizon Universal 3-GPU Harness Pod

**Revision:** 2.0-draft  
**Date:** 2026-09-30  
**Purpose:** Astra/FreeCAD engineering handoff and future-recall package.

## Frozen design intent

This project is no longer a four-card RTX-3060-specific rack. It is a **universal, three-GPU external harness pod**.

The first population is 3 × MSI RTX 3060 Ventus 2X 12GB. Those cards are a validation case, not the geometry definition. Future pods may use different GPUs if they remain inside the acceptance envelope or the adjustable carrier system is revised.

The main pod body is intended to be one continuous FDM print on the owner's Creality Ender-3 S1 Pro. **No mid-print spool swap is permitted.** The design must therefore be materially efficient and must complete from one large spool.

## Primary design priorities

1. Clean, professional mechanical assembly.
2. No machine screws threaded directly into printed plastic.
3. Heat-set inserts, through-bolts, captive nuts, and metal component threads only.
4. Three independent GPU carrier positions with adjustable spacing.
5. GPU length may overhang the printed core rather than forcing the print to match card length.
6. Strong airflow lanes between cards, fed from a pressure plenum.
7. Cable paths are designed into the chassis, not zip-tied as an afterthought.
8. Each pod is self-contained in power and cooling.
9. Expansion is by adding another three-GPU pod, not making this pod larger.
10. Multi-pod expansion uses software/control discovery plus independent PCIe uplinks; it does not passively daisy-chain PCIe lanes.

## Start here

- `01_SYSTEM_ARCHITECTURE.md` — compute/data architecture and host lane map.
- `02_MECHANICAL_BLUEPRINT.md` — chassis coordinate system, universal GPU envelope, carrier interfaces, PSU and fan placement.
- `03_AIRFLOW_CHANNELS.md` — fan wall, plenum, card gaps and baffles.
- `04_FASTENERS_AND_INSERTS.md` — exact fastener families, insert pockets and mounting rules.
- `05_PRINT_MATERIAL_AND_SLICER_STRATEGY.md` — one-spool requirement, chosen material, where material can be removed and where reinforcement belongs.
- `06_CABLE_MANAGEMENT_AND_POWER.md` — separated high-current/data channels and service loops.
- `07_ELECTRONICS_INTERFACE.md` — universal receiver-board sled and PCB mounting approach.
- `08_EXPANSION_PODLINK.md` — future multi-pod mechanical/control standard.
- `09_BOM_CURRENT.md` — purchase list and current price targets.
- `10_ASTRA_FREECAD_HANDOFF.md` — direct engineering brief for Astra.
- `11_VALIDATION_AND_TEST_PLAN.md` — print, mechanical, electrical and thermal acceptance.
- `parameters.json` / `decisions.json` — machine-readable state.

## Important honesty boundary

The exact PCIe bifurcation transport/receiver board is **not frozen** yet. Therefore this package deliberately does not invent its PCB hole coordinates. Instead, the pod uses a universal removable electronics sled with slots and metal-thread fastening. Once the exact receiver board is purchased, Astra should model a small board-specific adapter plate rather than redesigning the entire chassis.

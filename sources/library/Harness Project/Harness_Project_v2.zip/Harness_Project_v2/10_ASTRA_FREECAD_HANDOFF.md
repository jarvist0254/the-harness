# Astra / FreeCAD Handoff — Design the Universal 3-GPU Harness Pod

## Mission

Create a production-minded, parametric FreeCAD model for a **single-piece printable core chassis** that supports exactly three external desktop GPUs plus modular receiver-board sleds, cooling plenum, cable management and an external ATX PSU locating system.

Do not produce a four-GPU chassis. Expansion is another identical three-GPU pod.

## Hard printer constraints

Printer: Creality Ender-3 S1 Pro
Nominal volume: 220 × 220 × 270mm.

Keep the monolithic core within:
- X ≤ 205mm
- Y ≤ 205mm
- Z ≤ 250mm

Prefer smaller. Leave practical room for brim and printer dimensional error.

## Parametric variables

Create named parameters at minimum:

```text
CORE_X = 205
CORE_Y = 200
CORE_Z = 245
WALL_LOW = 2.4
SPINE = 4.8
RIB = 4.8
GUSSET = 5.4
CORNER_R = 6

GPU_COUNT = 3
GPU_L_MIN = 180
GPU_L_MAX = 360
GPU_H_MAX = 155
GPU_T_MIN = 35
GPU_T_NOMINAL_MAX = 60
GPU_MASS_MAX_KG = 2.0
AIR_GAP_MIN = 15
AIR_GAP_PREF = 20
POWER_SERVICE = 45

FAN_SIZE = 120
FAN_THICKNESS = 25
PLENUM_DEPTH = 42

M3_INSERT_OD_REF = 4.6
M3_INSERT_L_REF = 5.7
M3_POCKET_REF = 4.0
M4_INSERT_OD_REF = 6.3
M4_INSERT_L_REF = 8.1
M4_POCKET_REF = 5.6
```

Treat insert numbers as reference values only; actual purchased inserts are measured before final release.

## Geometry concept

- GPUs upright, parallel, length along Y, height Z, thickness X.
- Front face contains two vertically stacked 120mm fan mounts.
- Fans blow through an expanding common plenum into four airflow lanes across the GPU bank.
- Rear is open.
- Three independent carrier stations A/B/C.
- Carrier positions adjustable using M4 machine screws into brass inserts.
- Outer cards are allowed to project through large side windows.
- Cards longer than core depth overhang rear.
- Core is a ribbed space frame, not a box full of infill.

## Carrier mechanical interface

Each carrier needs:
1. removable electronics sled attached with 4 × M4 screws;
2. GPU I/O bracket retention using M3 metal-thread fastener points;
3. adjustable mid/rear support rail;
4. M3/M4 strain-relief anchor points;
5. no support on fan blades, exposed PCB, inductors, capacitors or hot heatsink fins.

The rear support contact shall be a replaceable shoe with rubber/TPU pad, not a hard permanent shape tied to the RTX 3060.

## Universal PCB sled

Do not model exact receiver-board holes.

Create a separate replaceable sled with:
- skeletal 170 × 105mm-class envelope
- 3.6–4.0mm-wide longitudinal mounting slots
- M3/M2.5 standoff compatibility
- four M4 chassis attachment points
- keepout volume around PCIe x16 socket
- cable-entry keepout for OCuLink/SlimSAS/MCIO family

## Fastener philosophy

No machine screw directly into plastic.

Use:
- M3 heat-set inserts for electronics/light covers
- M4 heat-set inserts for carriers and pod couplers
- M4 through-bolts + nyloc nuts for fans where access permits
- component's own metal threads for ATX PSU rear screws

Add insertion access for soldering-iron heat-set tip. Do not bury insert holes where installation is impossible.

## Airflow

Two stacked 120mm fans → 35–50mm expanding plenum → four airflow lanes.

Plenum walls 1.8–2.4mm with ribs.
Baffle vanes 1.6–2.0mm, 35–60mm long, rounded leading edge.
Minimum cooling lane 15mm; preferred 18–25mm.

Do not close the exhaust end.

## Cable management

Integrate three segregated trunks:
- data: ~28 × 18mm minimum
- GPU power: ~38 × 24mm minimum
- fan/control: ~18 × 12mm minimum

Use removable covers fixed to M3 inserts.
Use 4–5mm slots for hook-and-loop cable ties every 50–80mm.
Provide P-clamp bosses for strain relief.
Avoid 90° cable turns.

## Material efficiency

We will print in one 5kg PETG spool. Target chassis mass ≤2.8kg, acceptable ≤3.5kg after review. Hard project limit ≤4.3kg including print extras.

Remove material with:
- large side windows
- open floor between beams
- ribbed plenum panels
- skeletal electronics trays
- perforated cable covers

Reinforce only:
- carrier M4 insert zones
- bracket bulkhead
- rear cradle rail roots
- feet
- PSU saddle roots
- fan wall corners
- pod-coupling bosses

Do not solve stiffness by globally increasing infill.

## FreeCAD outputs requested

1. master `.FCStd` parametric model
2. core chassis body
3. universal PCB sled
4. rear GPU support shoe
5. optional PSU stop/strap bracket
6. cable-raceway covers
7. heat-set insert coupon
8. simplified dummy GPU body controlled by L/H/T parameters
9. simplified fan bodies
10. STEP export of assembly
11. STL/3MF of print-ready bodies only after interference check

## Interference / design checks

Before declaring model done:
- sweep GPU dummy from 35 to 60mm thickness
- test 155mm height
- test 360mm length with rear overhang
- validate 15mm minimum intake gap
- validate power connector service volume
- validate 5kg-spool print mass target in slicer
- ensure every screw has tool access
- ensure every insert has heat-set installation access
- ensure receiver sled can be removed without removing the entire chassis
- ensure each GPU can be removed independently
- ensure fan replacement does not require cutting wires or destroying plastic
- ensure no printed feature blocks GPU exhaust

## First-population validation geometry

Use MSI RTX 3060 Ventus 2X 12G OC as the first fit check:
- 235 × 124 × 42mm
- 675g
- single 8-pin power connector

All three must fit simultaneously with healthy air lanes, but the model must not become dimensionally dependent on this card.

# Mechanical Envelope — Universal Three-GPU Pod

## Print versus operating orientation

The one-piece chassis is designed to be printed on its side and rotated into service.

**Maximum print bounding box:** 200 × 188 × 254 mm  
**Operational printed body:** ~254 W × 200 D × 188 H mm

This fits the Ender-3 S1 Pro nominal 220 × 220 × 270 mm build volume while leaving usable bed and Z margin.

## Three universal GPU bays

Max target per bay:

- thickness: 68 mm
- body height: 165 mm
- length: 360 mm by rear overhang
- mass: 1.2 kg without tail support; 2.2 kg with adjustable metal-supported tail restraint

Width map:

```text
13 structure | 68 Bay A | 12 air | 68 Bay B | 12 air | 68 Bay C | 13 structure
= 254 mm
```

The card position inside each 68 mm envelope is adjustable. Thinner cards should gain airflow clearance rather than being centered by default.

## First-population validation card

MSI RTX 3060 Ventus 2X 12G OC:

- 235 L × 124 H × 42 T mm
- 675 g
- 170 W

The universal geometry must not be collapsed to those dimensions.

## GPU supports

Each bay includes:

- front receiver datum
- adjustable lateral shoe
- independent I/O bracket restraint
- padded safe-contact card-body support
- optional metal-supported far-end cradle

No printed cantilever alone should carry the tail of a long/heavy card.

## Receiver layer

Three ADT F9Q-BK10 receiver zones sit on a slotted service tray. Exact fixed hole coordinates stay TBD until the official ADT CAD or physical board is imported.

Use M3 metal standoffs through slotted holes with washers/nuts; no PCB rests directly on the printed chassis.

## Fan/plenum geometry

- 2 × 120 × 120 × 25 mm fans side-by-side across the 254 mm width
- 25–35 mm common pressure plenum
- minimum 12 mm inter-card channel at 68 mm max-card envelope
- open rear/card-edge exhaust

## PSU restraint

The printed body provides reinforced hardpoints and saddle/strap geometry; the ATX PSU may hang beneath/rearward of the printed bounding box after assembly.

Reference RM1000x dimensions: 160 × 150 × 86 mm. Parameterize this value.

Use metal straps + M4 through-bolts + washers/nyloc nuts and elastomer pads. Do not treat printed PETG as a tapped PSU mounting structure.

## Chassis sections

- General wall: 2.4–3.0 mm
- Structural ribs: 5–7 mm effective section
- Major M4 hardpoint region: 7–10 mm effective section with ribs
- Internal fillets: 3–6 mm target
- Large radiused lightening windows away from load paths
- No full solid floor; use rails/crossmembers

## Expansion dock

Provide a flat side/rear dock with four M4 holes on an 80 × 60 mm rectangular pattern and a 42 × 30 mm blanked center zone for future control/active-fabric connectors.

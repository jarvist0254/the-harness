# Power Architecture and Cabling

## 1. Pod power domain

The three-GPU pod has one external PSU that powers the pod GPUs and the external receiver/dock hardware according to the dock manufacturer’s approved connection scheme.

Do not power a GPU slot from one PSU and the same GPU’s auxiliary connector from another PSU unless the exact receiver design explicitly requires and supports it.

## 2. Current load case

RTX 3060 Ventus 2X board power: 170 W each.

- 3 × 170 W = 510 W GPU board-power budget
- add receiver electronics, fans, control, and transient margin

A quality 1000 W unit provides large operating margin for this first population.

## 3. PSU candidate

Corsair RM1000x, current ATX 3.1 model CP-9020271-NA.

Published dimensions: 160 × 150 × 86 mm.  
Published native cable inventory includes:

- 4 × independent PCIe 8-pin (6+2) cables, one connector each
- 1 × native 12V-2x6 cable
- 2 × EPS cables
- SATA/PATA peripheral leads

That is particularly useful for three current 3060s because each can receive a dedicated native PCIe 8-pin cable with one spare.

Do not mix modular PSU cables from different PSU models.

## 4. Universal power caveat

The chassis is mechanically universal; the PSU sizing is **not** automatically universal.

If later GPUs are 300–450 W class, recalculate:

- total board power
- connector type/count
- transient requirements
- native cable inventory
- wall circuit loading
- receiver power arrangement

A three-slot chassis that physically accepts a card does not certify a 1000 W PSU for three copies of that card.

## 5. Fans

Two P12 Max fans at 0.29 A each on 12 V are roughly 7 W combined maximum electrical input by simple V×A arithmetic. Power them from an appropriate fan controller/hub fed by the pod PSU, not by overloading a random motherboard header across the external harness.

## 6. Power cabling layout

- GPU A native power lead -> raceway P-A
- GPU B native power lead -> raceway P-B
- GPU C native power lead -> raceway P-C
- receiver power -> dedicated manufacturer-approved connectors and route
- fan/control power -> low-current control raceway

No SATA-to-GPU power adapters. No unverified modular PSU cables. No daisy-chain splitters for high-current GPU feeds merely to reduce cable count.

## 7. Start sequence

Until automated sequencing is validated:

1. Host shut down.
2. Pod connections inspected.
3. Pod PSU on / receiver hardware powered according to ADT instructions.
4. Fans confirmed spinning or responding to controller.
5. Host powered on.
6. Verify all GPUs enumerate before launching J-Link workloads.

## 8. Stop sequence

1. Stop new J-Link work.
2. Drain/cancel active jobs and checkpoint as applicable.
3. Shut host down fully.
4. Turn pod PSU off.
5. Wait for discharge/status LEDs to extinguish.
6. Disconnect AC before servicing.

OCuLink is not hot-plugged in this design.


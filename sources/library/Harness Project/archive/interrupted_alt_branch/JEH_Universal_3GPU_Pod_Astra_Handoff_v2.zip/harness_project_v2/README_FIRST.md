# JE Horizon Universal 3-GPU Pod — README FIRST

**Revision:** 2.0-preCAD  
**Date:** 2026-09-30  
**Purpose:** Astra / Blender / mechanical-design handoff  
**Status:** CAD DESIGN AUTHORIZED; FINAL STL / PRODUCTION PRINT NOT YET RELEASED

## 1. Frozen design intent

Build **one universal three-GPU pod**. The chassis always has exactly three GPU bays. The first population is three MSI RTX 3060 Ventus 2X 12GB cards, but those cards are validation hardware, not the dimensional master.

Expansion means building another identical three-GPU pod. Pods may mechanically dock and share control/network infrastructure through the defined PodLink interface, but a passive pod-to-pod connector never creates PCIe lanes. Each added pod requires its own validated PCIe host path or active switching architecture. J-Link aggregates the resulting workers in software.

The pod uses a **single principal printed chassis body** plus post-installed metal rails/plates, machine screws, standoffs, fans, receiver hardware, PSU restraint and cable-management hardware. No serviceable structural screw is allowed to cut reusable threads directly into printed plastic.

## 2. Printer and single-spool constraint

Printer: **Creality Ender-3 S1 Pro**  
Nominal build volume: **220 × 220 × 270 mm**

Maximum principal-print bounding box:

- Print X <= **200 mm**
- Print Y <= **188 mm**
- Print Z <= **254 mm**

After printing, rotate the chassis into its operating orientation of roughly **254 W × 200 D × 188 H mm**.

The production chassis must complete from **one continuous 5 kg spool with no spool change**.

Release targets:

- preferred slicer filament mass <= **3.0 kg**
- hard ceiling <= **4.0 kg including brim/support**
- retain nominal >=20% spool reserve at the hard ceiling
- if the slicer exceeds the ceiling, remove plastic by redesigning low-load panels/raceways before weakening hardpoints

## 3. Material decision

Primary production material: **quality plain PETG, 1.75 mm, one continuous 5 kg spool**.

Why PETG for this specific build:

- substantially lower large-part warping risk than ASA/ABS/PC/nylon on an open S1 Pro
- good impact toughness and layer bonding for an open-frame equipment chassis
- compatible with heat-set inserts and conventional machine-hardware interfaces
- affordable in true 5 kg continuous spools
- does not require abrasive-fiber filament or a hardened nozzle

Recommended production nozzle: **0.6 mm**. Starting layer height: **~0.28 mm**, tuned with coupons and the selected PETG.

The print should be a ribbed monocoque, not a solid block. Broad panel centers, cosmetic skins, cable covers and non-load-bearing floor areas are the first places to remove material. Receiver rails, GPU support rails, fan bosses, PSU restraint hardpoints, PodLink hardpoints and cable strain-relief anchors are locally reinforced with additional walls/ribs and local infill.

## 4. Universal three-GPU envelope

Exactly three independent bays, A/B/C.

Target supported card envelope per bay:

- body thickness: **35–68 mm**
- body height: **<=165 mm**
- length: **<=360 mm** with intentional rear overhang / tail support
- mass: <=1.2 kg without tail support; <=2.2 kg with the defined tail support

At the maximum 68 mm thickness, preserve **>=12 mm clear inter-card air channels**. Thinner cards must use adjustable shoes/clamps so their unused width becomes airflow rather than dead space.

Initial validation GPU: MSI RTX 3060 Ventus 2X 12G OC, **235 × 124 × 42 mm, 675 g, 170 W**.

## 5. Airflow and cable architecture

Cooling target: **2 × 120 × 120 × 25 mm pressure-oriented PWM fans** (ARCTIC P12 Max or equivalent) feeding a **25–35 mm common pressure plenum**.

Do not block GPU exhaust with a decorative rear wall.

Maintain three distinct routing classes:

1. OCuLink / high-speed PCIe signal
2. GPU + receiver DC power
3. fan/PWM/telemetry/control

Do not force OCuLink and high-current GPU power into the same tight raceway. Provide rounded exits, strain relief on cable jackets rather than connectors, removable machine-fastened raceway covers, and deterministic A/B/C labeling at both ends.

## 6. Metal-thread rule

Structural/service joints use metal interfaces:

- **M4** through-bolt + washer + nyloc/captive metal nut for primary structure
- **M3** machine screw + metal standoff for PCB/electronics
- M3/M4 brass heat-set inserts only for secondary/removable service interfaces
- fan mounting uses M4 machine screws, washers and locknuts
- PSU restraint uses metal straps/plates and M4 hardpoints
- GPU support uses metal rails/adjusters where concentrated load occurs

No reusable structural thread is cut directly into PETG.

## 7. PCIe topology

Host: MSI PRO X870-P WIFI + Ryzen 7 7700.

- PCI_E1: x4+x4+x4+x4 bifurcation; Pod 1 consumes three x4 branches.
- Host-adapter reference: RIITOP PCIe 4.0 x16 -> 4 × OCuLink SFF-8612.
- Receiver reference: ADT-Link F9Q-BK10, one per GPU.
- PCI_E4: separate Gen4 x4 path for the RTX 5070 Ti.
- M2_3: remains empty to preserve PCI_E4 x4.

The fourth PCI_E1 branch is spare; by itself it cannot feed another three-GPU pod.

## 8. Critical unresolved geometry — do not invent

The ADT F9Q-BK10 vendor publishes 3D CAD, but its exact board-hole coordinates have not yet been imported into the model. Therefore the design uses a universal slotted receiver carrier until vendor CAD or a physical board is measured.

Also verify before production STL:

- exact selected PSU and cable-projection envelope
- actual OCuLink connector body and cable bend limits
- final receiver-board mounting geometry and underside clearance
- actual max-card contact points for adjustable supports

Do not guess these dimensions just to finish an STL.

## 9. Source-of-truth reading order for Astra

Read these **current** files in order:

1. `README_FIRST.md`
2. `MASTER_BLUEPRINT.md`
3. `CAD_PARAMETERS.json` / `CAD_PARAMETERS.md`
4. `MATERIAL_AND_PRINT_PLAN.md`
5. `FASTENERS_AND_HARDPOINTS.md`
6. `AIRFLOW_AND_CABLE_CHANNELS.md`
7. `MECHANICAL_ENVELOPE.md`
8. `CURRENT_ARCHITECTURE.md`
9. `POWER_AND_CABLING.md`
10. `POD_EXPANSION_INTERFACE.md`
11. `J_LINK_SOFTWARE_FABRIC.md`
12. `PURCHASE_AND_BOM.md`
13. `VALIDATION_CHECKLIST.md`
14. `SOURCE_MANIFEST.md`
15. `DECISIONS.md` / `decisions.json`
16. `ASTRA_HANDOFF_PROMPT.md` — execute only after reading the above

Files under `/Harness Project/archive/` are historical only and **must not override current/**.

## 10. Astra output expectation

Astra should create the parametric Blender/CAD design, not blindly reproduce a rectangular box. Required outputs include:

- native `.blend`
- parametric dimensions / named variables
- maximum-envelope and first-population GPU mockups
- section views for airflow and cable channels
- exploded hardware view
- adjustable receiver carrier with F9Q geometry held as TBD until verified
- metal-thread / through-bolt joint details
- PSU restraint and service access
- PodLink interface
- estimated printed volume and PETG mass
- print orientation inside 200 × 188 × 254 mm
- collision/clearance report

Do not issue production STL until every release gate in `VALIDATION_CHECKLIST.md` passes.

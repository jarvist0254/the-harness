# Validation Checklist — Universal 3-GPU Pod

## CAD gate

- [ ] Master print bounding box <=200 × 188 × 254 mm
- [ ] 5 mm brim fits 220 × 220 bed
- [ ] no hidden modifiers/supports exceed build volume
- [ ] 3 × max-envelope GPUs (68 × 165 × 360) clear chassis
- [ ] first-population RTX 3060 envelopes (42 × 124 × 235) clear chassis
- [ ] each GPU removable independently
- [ ] 12 mm minimum AB/BC airflow gaps preserved at max envelope
- [ ] two 120 × 120 × 25 fans fit fan wall
- [ ] 25–35 mm common intake plenum modeled
- [ ] exhaust side/rear remains open

## Receiver gate

- [ ] ADT F9Q-BK10 official CAD imported OR actual board measured
- [ ] mounting-hole diameter measured/verified
- [ ] standoff coordinates verified
- [ ] underside component keepout verified
- [ ] OCuLink connector service/bend zone verified
- [ ] receiver switch/LED access retained
- [ ] no PCB rests directly on PETG

## Fastener gate

- [ ] all structural joints use through-bolts/captive nuts or metal standoffs
- [ ] no structural self-tapped machine screw into PETG
- [ ] M3/M4 heat-set insert coupon printed and measured
- [ ] fan screw length selected from final stack, not guessed
- [ ] PSU straps terminate in M4 metal hardware
- [ ] broad washers used on PETG load faces

## Material gate

- [ ] one fresh 5 kg PETG spool available
- [ ] spool dry and feed path validated
- [ ] external 5 kg spool roller stable
- [ ] slicer total mass including supports/brim <=4.0 kg hard ceiling
- [ ] preferred slicer total <=3.0 kg
- [ ] no mid-print spool change required

## Airflow/cable gate

- [ ] OCuLink raceway does not enter 12 mm minimum GPU air channels
- [ ] GPU power raceways separate from signal path where practical
- [ ] 25–40 mm straight service zone at OCuLink connectors
- [ ] GPU power connectors can latch/unlatch without removing neighbor card
- [ ] 12V-2x6-compatible service region has no forced immediate bend
- [ ] fan wires cannot enter blades
- [ ] strain relief clamps cable jacket, not connector

## Electrical bring-up

- [ ] BIOS set to PCI_E1 x4+x4+x4+x4
- [ ] M2_3 confirmed empty
- [ ] Pod initially tested with one receiver + one GPU
- [ ] cold boot repeatability passes
- [ ] negotiated link generation/width recorded
- [ ] add second GPU and repeat
- [ ] add third GPU and repeat
- [ ] RTX 5070 Ti on PCI_E4 checked simultaneously
- [ ] no Code 12/43 or persistent link retraining errors

## Thermal / mechanical burn-in

- [ ] idle temperatures recorded
- [ ] one-GPU load temperatures recorded
- [ ] three-GPU simultaneous load recorded
- [ ] receiver temperature checked
- [ ] printed hardpoints checked for softening/creep
- [ ] PSU intake/exhaust unobstructed
- [ ] cable jackets not hot/abraded
- [ ] no fan/plenum resonance loosens hardware
- [ ] fastener preload rechecked after first thermal cycle

## J-Link integration

- [ ] physical Bay A/B/C mapped to GPU UUIDs
- [ ] measured H2D/D2H bandwidth stored per GPU
- [ ] per-GPU VRAM/temp/power telemetry works
- [ ] workload scheduler respects topology/bandwidth asymmetry
- [ ] loss of one worker does not wedge whole scheduler
- [ ] no code treats aggregate VRAM as one contiguous allocation


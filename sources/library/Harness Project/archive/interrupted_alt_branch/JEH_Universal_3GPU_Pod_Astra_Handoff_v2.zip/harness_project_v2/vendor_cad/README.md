# Vendor CAD Retrieval

## ADT-Link F9Q-BK10

Official product page:
https://www.adt.link/product/F9Q.html

Official CAD archive advertised by ADT:
https://www.adt.link/download/ADT_F9Q_BK10_3D.zip

The archive must be downloaded/imported by Astra or the user before final receiver-hole geometry is frozen. Do not derive hole centers from web photos.

## ARCTIC P12 Max

Official product page:
https://www.arctic.de/us/P12-Max/ACFAN00280A

Official support page with 120 mm mounting-hole pattern and P12 Max 2D drawing:
https://support.arctic.de/en/p12-max/docs

Import/verify the 2D drawing before final fan-hole placement.


# Purchase / BOM — Universal 3-GPU Pod

**Prices observed 2026-09-30; verify at checkout.**  
Amazon is preferred for commodity hardware, but exact SKU/electrical compatibility outranks one-cart convenience.

## A. Compute hardware

### 1. First GPU population — buy 3

MSI GeForce RTX 3060 Ventus 2X OC 12GB refurbished  
Current user-selected listing: approximately $359.99 each when checked.  
Quantity 3 = $1,079.97 before tax at that observed price.

Newegg:
https://www.newegg.com/msi-rtx-3060/p/1FT-0009-00B46

Exact MSI mechanical/electrical envelope used only for first-population validation:
235 × 124 × 42 mm, 675 g, 170 W, 1 × 8-pin.

## B. Host PCIe breakout

### 2. RIITOP PCIe 4.0 x16 -> four OCuLink SFF-8612 ports — buy 1

Observed manufacturer price: $48.99.  
Newegg RIITOP-sold listing observed around $46.99.

Manufacturer:
https://www.riitop.com/products/riitop-pcie-to-oculink-adapter-4-port-pcie-4-0-x16-to-sff-8612-sff-8611-female-full-speed-64gbps-4port-for-egpupci-e-x4x4x4x4-bifurcation-required

Newegg:
https://www.newegg.com/p/17Z-0061-000E4

Amazon search / verified model search term:
`RIITOP 4-Port PCIe 4.0 x16 OCuLink SFF-8612 B0F3JMZSVF`

Use only 3 of 4 ports for Pod 1.

## C. Three external receivers

### 3. ADT-Link F9Q-BK10 — buy 3 after one-sample fit/electrical check if return logistics are poor

Preferred because it includes a PCIe Gen4 x4 OCuLink path, x16 mechanical GPU slot and a redriver.

Official:
https://www.adt.link/product/F9Q.html

Vendor CAD:
https://www.adt.link/download/ADT_F9Q_BK10_3D.zip

Key verified traits:

- Gen4 x4 / 64 Gbps theoretical link signaling claim
- 50 cm OCuLink cable in product description
- redriver-equipped
- supports standard ATX/SFX PSU
- no hot swap

**Do not buy a visually similar no-name dock and assume the same board dimensions/hole pattern.**

## D. PSU

### 4. Corsair RM1000x ATX 3.1 CP-9020271-NA — buy 1

Current new retail varies; official/refurbished listings may differ. A Corsair Revival Series listing was observed at $99.99; standard retail listings have been around $170–$210.

Official:
https://www.corsair.com/us/en/p/psu/cp-9020271-na/rmx-series-rm1000x-fully-modular-power-supply-cp-9020271-na

Published cable set includes four independent PCIe 8-pin (6+2) cables plus one 12V-2x6 cable.

Do not substitute another 1000 W PSU without rechecking native GPU cable count and modular pinout.

## E. Cooling

### 5. ARCTIC P12 Max — buy 2 (or one multi-pack if cheaper)

Official MSRP: $17.99 each when checked.

Official:
https://www.arctic.de/us/P12-Max/ACFAN00280A

Spec: 120 × 120 × 25 mm, 400–3300 rpm, 81.04 CFM, 4.35 mmH2O, 12 V, 0.29 A, 4-pin PWM.

Amazon preferred search term:
`ARCTIC P12 Max 120mm PWM`

### 6. Fan controller/hub — buy 1

Requirements:

- SATA-powered or otherwise PSU-powered
- 4-pin PWM control
- >=2 P12 Max outputs with adequate current rating
- do not draw both high-speed fans directly through an underspecified remote motherboard header

Amazon search term:
`SATA powered PWM fan hub 4 pin`

## F. Print material

### 7. ZYLtech 5 kg High Speed High Flow PETG — buy 1 fresh spool

Observed price: $79.95.

https://www.zyltech.com/5kg-texas-size-spool-high-speed-high-flow-petg-3d-printer-filament-1-75mm-11-lbs-made-in-usa/

Alternative regular 5 kg PETG: $76.95 observed.

https://www.zyltech.com/5kg-texas-size-spool-petg-3d-printer-filament-1-75-mm-11-lbs/

Reason for non-Amazon exception: one guaranteed continuous 5 kg spool matters more than consolidating this line item into Amazon. A spool change mid-production print is explicitly disallowed.

### 8. External 5 kg spool roller/holder — buy 1

Do not mount a 5 kg spool to the printer gantry.

Requirement: rated for >=5 kg, bearing rollers, stable base, low-friction feed.

Amazon search term:
`5kg filament spool holder roller 3D printer`

## G. Structural fasteners

Amazon is appropriate for these commodity items. Buy exact metric sizes; avoid mixed mystery hardware where quantities are too small.

### M4 structural assortment

Buy enough to cover:

- 20 × M4×10
- 30 × M4×12
- 30 × M4×16
- 20 × M4×20
- 12 × M4×30
- 12 × M4×35
- 100 × M4 flat washers
- 60 × M4 nyloc nuts
- 30 × M4 standard nuts

Amazon search term:
`M4 304 stainless socket head cap screw assortment M4x10 M4x12 M4x16 M4x20 M4x30 M4x35 washers nyloc`

### M3 electronics assortment

Buy enough to cover:

- 30 × M3×6
- 30 × M3×8
- 30 × M3×10
- 60 × M3 washers
- 30 × M3 nuts/nyloc

Amazon search term:
`M3 stainless socket head machine screw assortment washers nuts`

## H. Heat-set inserts

### 9. ruthex RX-M3x5.7 — 100 pack

Use for covers/electronics/control interfaces.

Manufacturer:
https://www.ruthex.de/en/collections/gewindeeinsatze/products/ruthex-gewindeeinsatz-m3-100-stuck-rx-m3x5-7-messing-gewindebuchsen

Amazon search term:
`ruthex RX-M3x5.7 100`

### 10. ruthex RX-M4x8.1 — 50 pack

Use for serviceable secondary M4 joints where through-bolt is impractical.

Manufacturer:
https://www.ruthex.de/en/products/ruthex-gewindeeinsatz-m4-50-stuck-rx-m4x8-1-messing-gewindebuchsen

Amazon search term:
`ruthex RX-M4x8.1 50`

## I. PCB standoffs

### 11. M3 brass standoff kit — buy 1

Needs at least:

- 12 × 6 mm M3 female/female or male/female standoffs
- 12 × 10 mm M3 standoffs
- matching M3 screws/nuts

Amazon search term:
`M3 brass standoff kit 6mm 10mm`

Final receiver standoff height is chosen after F9Q CAD/board measurement.

## J. Vibration / contact material

### 12. EPDM or neoprene sheet — buy 1 small sheet

- 1–2 mm thick
- adhesive-backed optional
- use only as isolation/contact pad, not structural adhesive

Amazon search term:
`1mm 2mm neoprene rubber sheet adhesive`

## K. PSU restraint

### 13. Stainless perforated strap or narrow metal mounting straps — buy 2

- 15–25 mm wide
- enough length to wrap/bridge the selected PSU cradle geometry
- holes compatible with M4 hardware or drillable off-chassis before assembly

Amazon search term:
`stainless perforated mounting strap 20mm`

## L. GPU tail support metal

### 14. Adjustable metal tail-support stock — buy after Astra geometry

Likely one of:

- M4/M5 stainless threaded rod + nuts/washers
- 10–15 mm wide aluminum flat bar
- small T-slot rail

Do not buy until Astra resolves exact tail-support design.

## M. Cable management

### 15. Reusable hook-and-loop ties — 30 pack

Use around removable cable bundles. Do not cinch high-speed OCuLink tightly.

### 16. Rubber-lined P-clamps — M3/M4 mounting, mixed 6–15 mm cable sizes

Use for strain relief at chassis hardpoints.

### 17. Braided sleeve — 6/10/15 mm sizes as required

Keep OCuLink and high-current GPU power in separate bundles.

### 18. Label sleeves / heat-shrink labels

Label POD/GPU/LINK/PWR at both ends.

## N. Fabrication tools/consumables if not already owned

- 0.6 mm nozzle for PETG
- heat-set insert soldering tips for M3/M4
- digital caliper
- deburring tool/reamer
- M3/M4 hex keys/torque-conscious hand driver
- side cutters and cable shears
- thread-locker only where compatible and not contacting PETG; nyloc is preferred for most chassis joints

## O. What NOT to buy

- mining USB x1 risers
- SATA-to-PCIe GPU power adapters
- passive PCIe Y splitters
- random modular PSU cables
- fan self-tapping screws as structural fasteners
- carbon/glass-filled filament for the first production chassis
- a 1–2 kg filament spool that forces a mid-print swap


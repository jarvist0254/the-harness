# Current Electrical and Compute Architecture — 3-GPU Pod Revision

## Host

- Motherboard: MSI PRO X870-P WIFI
- CPU: AMD Ryzen 7 7700
- Memory: 64 GB DDR5
- Existing primary GPU: RTX 5070 Ti 16 GB
- M2_1: occupied
- M2_2: occupied
- M2_3: **must remain empty** if PCI_E4 x4 is required

## Pod topology

MSI documents PCI_E1 on Ryzen 7000/9000 as supporting x4+x4+x4+x4 bifurcation.

Preferred host adapter: RIITOP PCIe 4.0 x16 → 4 × OCuLink SFF-8612, which explicitly requires x4+x4+x4+x4 bifurcation.

This pod uses **three** of those four branches:

```text
PCI_E1 CPU x16
  BIOS = x4/x4/x4/x4
      branch 0 -> OCuLink -> POD-1 receiver A -> GPU A
      branch 1 -> OCuLink -> POD-1 receiver B -> GPU B
      branch 2 -> OCuLink -> POD-1 receiver C -> GPU C
      branch 3 -> reserved/unused in this revision

PCI_E4 chipset Gen4 x4
      -> independent external extension -> RTX 5070 Ti

M2_3 = EMPTY
```

Do not interpret the unused fourth branch as enough capacity for a second three-GPU pod. A second pod needs three additional validated PCIe links, an active switch architecture, or another host/network node.

## First GPU population

- Pod A: MSI RTX 3060 Ventus 2X 12GB
- Pod B: MSI RTX 3060 Ventus 2X 12GB
- Pod C: MSI RTX 3060 Ventus 2X 12GB
- RTX 5070 Ti 16GB remains a separate worker on PCI_E4

Initial physical VRAM across all four GPUs: 52 GB. This is not unified VRAM.

## Receiver candidate

ADT-Link F9Q-BK10:

- OCuLink SFF-8611/SFF-8612 to PCIe x16 mechanical
- PCIe 4.0 x4
- 50 cm cable
- redriver IC
- ATX/SFX PSU support
- no hot swap
- vendor 3D CAD available

## J-Link software model

J-Link is the JE Horizon GPU orchestration layer. It should discover each device and record:

- PCI bus ID
- GPU UUID
- CUDA capability
- VRAM total/free
- bay A/B/C physical mapping
- negotiated PCIe generation and width
- measured host-device transfer bandwidth
- temperature/power/utilization

Primary workloads:

- independent resident model workers
- parallel agents/tasks
- model-specific worker pinning
- pipeline stages

Experimental after validation:

- PyTorch DDP
- DeepSpeed
- FSDP
- explicit model sharding

J-Link must never assume all VRAM is one contiguous pool.

